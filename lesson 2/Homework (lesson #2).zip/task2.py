# 'Welcome to the Python World'
print ('Welcome to the Python World\n')

# 'Welcome to the Python World!'
print ('Welcome to the Python World', end = '!\n\n')

# 'Welcome to the'
# 'Python World'
print ('Welcome to the\nPython World\n\n')

# 'Welcome'
# 'to'
# 'the'
# 'Python'
# 'World'
print ('Welcome', 'to', 'the', 'Python', 'World', sep='\n')